"""
Utils module initialization
"""