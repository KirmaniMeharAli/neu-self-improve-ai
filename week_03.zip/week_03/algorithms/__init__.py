"""
Algorithms module initialization
"""